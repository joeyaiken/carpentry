// import { SELECT_DECK, ADD_DECK, LOG_STATE, SELECTED_DECK_CHANGE } from '../actions'
import Redux from 'redux'
import { Stream } from 'stream';
// import React from 'react'

import { 
    APP_NAV_CLICK,
    CARD_BINDER_SHEET_TOGGLE
} from '../actions'


export interface uiActionsProps {
    //  is app nav open
    //  is a side sheet open?
    //
    //
}

// interface UI {
//     isNavOpen: boolean;
//     isSideSheetOpen: boolean;
//     visibleSideSheet: string;

//     deckView: string;
//     deckGroup: string;
//     deckSort: string;
// }



//export const ui = (state: uiActionsProps, action: ReduxAction): ReducerMapObject<uiActionsProps> => {
export const ui = (state: UIState, action: ReduxAction): any => {
    switch(action.type){
        case APP_NAV_CLICK:
            return {
                ...state,
                isNavOpen: !state.isNavOpen
            }
        case CARD_BINDER_SHEET_TOGGLE: 
            ///isSearchOpen: boolean;
            // isRareBinderOpen: boolean;
            // isDetailOpen: boolean;
            return {
                ...state,
                isSideSheetOpen: true,
                visibleSideSheet: action.payload
                // isSearchOpen: false,
                // isRareBinderOpen: false,
                // isDetailOpen: false,
                // [action.payload]: true
            }


        // case OPEN_FIND_MODAL:
        //     return {
        //         isFindModalVisible: true
        //     } as uiActionsProps;
        // case CLOSE_FIND_MODAL:
        //     return {
        //         isFindModalVisible: false
        //     } as uiActionsProps;
        default:
            console.log('ui state default reducer');
            console.log(state);
            if(!state){
                state = {
                    // isFindModalVisible: true
                    isNavOpen: false,
                    isSideSheetOpen: true,
                    visibleSideSheet: '',

                    deckView: 'card',
                    deckGroup: 'none',
                    deckSort: 'name',
                    deckFilter: ''
                }// a
            }
            return state;
            // return {
            //     // isFindModalVisible: true
            //     something: true
            // }// as uiActionsProps;
    }
}


function decaultUiState(): uiActionsProps {
    return {


    } as uiActionsProps;
}
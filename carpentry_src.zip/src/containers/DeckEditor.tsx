import { connect, MapStateToProps, DispatchProp } from 'react-redux'
import React, { Component, SyntheticEvent } from 'react'
import {
    selectDeck,
    deckChanged,
    saveDeck,
    onSectionToggle,
    cardBinderSheetToggle,
    // selectDeck,
    // deckChanged
    searchApplied,
    searchValueChange,
    searchCardSelected,
    addCardToDeck,
    cardBinderLandCountChange,
    cardBinderViewChange,
    cardBinderGroupChange,
    cardBinderSortChange,
    // cardDetailRequested,
    fetchCardsIfNeeded
} from '../actions'


import EditorOptions from './EditorOptions';
import DeckList from '../components/DeckList';
import DeckDetail from '../components/DeckDetail';
import DeckBuilder from '../components/DeckBuilder';
import DeckQuickStats from '../components/DeckQuickStats';
import CardBinder from '../components/CardBinder';
import CardQuickAdd from './CardQuickAdd';
import RareBinder from '../components/RareBinder';

import MaterialButton from '../components/MaterialButton'

/**
 * 
 * The Deck Editor is basically a fancy data table
 * 
 */





interface PropsFromState {
    deckList: CardDeck[];
    selectedDeckId: number;
    sectionVisibilities: boolean[];
    // dispatch?: any;


    isSearchOpen: boolean;
    isRareBinderOpen: boolean;
    isDetailOpen: boolean;


    display: string | null; // card | list

    groupBy: string; // spellType | rarity | none
    //spell type icon   flash_on
    //rarity icon       grade
    //name icon         text-format
    //mana cost icon    battery-unknown | signal_cellular_alt
    sortBy: string | null; //manaCost | name | rarity
}

type DeckEditorProps = PropsFromState & DispatchProp<ReduxAction>;

class DeckEditor extends React.Component<DeckEditorProps> {
    constructor(props: DeckEditorProps) {
        super(props)
        this.handleDeckSelected = this.handleDeckSelected.bind(this);
        this.handleDeckChanged = this.handleDeckChanged.bind(this);
        this.handleDeckSaved = this.handleDeckSaved.bind(this);
        // this.handleSheetToggle = this.handleSheetToggle.bind(this);

        // this.handleCardClick = this.handleCardClick.bind(this);
        // this.handleLandCountChange = this.handleLandCountChange.bind(this);

        this.handleViewChange = this.handleViewChange.bind(this);
        this.handleGroupChange = this.handleGroupChange.bind(this);
        this.handleSortChange = this.handleSortChange.bind(this);
    }

    // componentDidMount() {
    //     // const { dispatch, selectedSubreddit } = this.props
    //     // dispatch(fetchPostsIfNeeded(selectedSubreddit))
    // }

    // componentDidUpdate(prevProps: any) {
    //     // if (this.props.selectedSubreddit !== prevProps.selectedSubreddit) {
    //     //   const { dispatch, selectedSubreddit } = this.props
    //     //   dispatch(fetchPostsIfNeeded(selectedSubreddit))
    //     // }
    // }
    
    // handleChange(nextSubreddit: any) {
    //     // this.props.dispatch(selectSubreddit(nextSubreddit))
    //     // this.props.dispatch(fetchPostsIfNeeded(nextSubreddit))
    // }
    
    // handleRefreshClick(e: any) {
    //     // e.preventDefault()

    //     // const { dispatch, selectedSubreddit } = this.props
    //     // dispatch(invalidateSubreddit(selectedSubreddit))
    //     // dispatch(fetchPostsIfNeeded(selectedSubreddit))
    // }

    handleDeckSelected(id: number) {
        this.props.dispatch(selectDeck(id))
    }

    handleDeckChanged(event: any, selectedDeck: CardDeck){
        
        const updatedDeck: CardDeck = {
            ...selectedDeck, [event.target.name]: event.target.value
        }
        // console.log(updatedDeck)


        this.props.dispatch(deckChanged(updatedDeck))
    }

    handleDeckSaved(){
        //localStorage.setItem('')
        this.props.dispatch(saveDeck())
    }

    handleSectionToggle(sectionIndex: number){
        console.log('sectionToggle: ' + sectionIndex)
        this.props.dispatch(onSectionToggle(sectionIndex));
    }

    // handleSheetToggle(section: string){
    //     this.props.dispatch(cardBinderSheetToggle(section))
    // }

    handleViewChange(view: string){
        // console.log('handling view change: '+view)
        this.props.dispatch(cardBinderViewChange(view));
    }

    handleGroupChange(group: string){
        // console.log('handling group change: '+group)
        this.props.dispatch(cardBinderGroupChange(group));
    }

    handleSortChange(sort: string){
        // console.log('handling sort change: '+sort)
        this.props.dispatch(cardBinderSortChange(sort));
    }

    render(){
        console.log('rendering deckEditor control')
        const { deckList, selectedDeckId } = this.props;
        const selectedDeck = deckList.find((deck) => {
            return deck.id == selectedDeckId
        }) || deckList[0];

        // console.log(selectedDeck);
        // let test = this.props;


        let deckViewOptions: JSX.Element = (
            <div className="card-header app-bar">
                    {/* <div className="header-section">
                        <label>Card Binder</label>
                    </div> */}
                    <div className="header-section">
                        <label>View:</label>
                        <MaterialButton value="card" isSelected={(this.props.display == "card")} icon="view_module" onClick={this.handleViewChange} />
                        <MaterialButton value="list" isSelected={(this.props.display == "list")} icon="view_headline" onClick={this.handleViewChange} />
                    </div>
                    <div className="header-section">
                        <label>Group:</label>
                        <MaterialButton value="none" isSelected={(this.props.groupBy == "none")} icon="view_headline" onClick={this.handleGroupChange} />
                        <MaterialButton value="spellType" isSelected={(this.props.groupBy == "spellType")} icon="flash_on" onClick={this.handleGroupChange} />
                        <MaterialButton value="rarity" isSelected={(this.props.groupBy == "rarity")} icon="grade" onClick={this.handleGroupChange} />
                    </div>
                    <div className="header-section">
                        <label>Sort:</label>
                        <MaterialButton value="name" isSelected={(this.props.sortBy == "name")} icon="text_format" onClick={this.handleSortChange} />
                        <MaterialButton value="rarity" isSelected={(this.props.sortBy == "rarity")} icon="grade" onClick={this.handleSortChange} />
                        <MaterialButton value="manaCost" isSelected={(this.props.sortBy == "manaCost")} icon="signal_cellular_alt" onClick={this.handleSortChange} />
                    </div>
                </div>
        );


        return(
            <div className="sd-deck-editor card">
                { deckViewOptions }
                {/* <div className="deck-editor-header card">
                    <div className="card-header">
                        <div className="header-section">
                            <label>Deck Editor: </label>
                        </div>
                        <div className="header-section pull-right">
                            <MaterialButton value="isDetailOpen" icon="list" onClick={this.handleSheetToggle} />
                            <MaterialButton value="isSearchOpen" icon="search" onClick={this.handleSheetToggle} />
                            <MaterialButton value="isRareBinderOpen" icon="grade" onClick={this.handleSheetToggle} />
                        </div>
                    </div>
                    
                </div> */}
                {/* <AvailableDecks /> */}
                {/* <EditorOptions /> */}
                {/* <DeckList deckList={deckList}
                          onDeckItemClicked={this.handleDeckSelected}
                          selectedDeck={selectedDeckId}
                          isOpen={this.props.sectionVisibilities[0]}
                          onHeaderToggle={() => this.handleSectionToggle(0)} /> */}


                {/* <div>Card Binder</div>
                <div>Quick Add</div>
                <div>Rare Binder</div> */}
                <CardBinder />
                {
                    (this.props.isDetailOpen) && 
                    <DeckDetail data={selectedDeck} 
                                handleChange={ (event: SyntheticEvent) => { this.handleDeckChanged(event, selectedDeck) }} 
                                handleSaveClick={this.handleDeckSaved}
                                isExpanded={true} />
                }
                {
                    (this.props.isSearchOpen) && <CardQuickAdd />
                }
                {
                    (this.props.isRareBinderOpen) && <RareBinder />
                }
                
                <DeckQuickStats />
            </div>
        )
    }

}

function mapStateToProps(state: State): PropsFromState {
    // const { selectedSubreddit, postsBySubreddit } = state
    // const { isFetching, lastUpdated, items: posts } = postsBySubreddit[
    //   selectedSubreddit
    // ] || {
    //   isFetching: true,
    //   items: []
    // }

    // console.log(state.actions.sectionVisibilities)

    const result: PropsFromState = {
        deckList: state.actions.deckList,
        selectedDeckId: state.actions.selectedDeckId,
        sectionVisibilities: state.actions.sectionVisibilities,
        isDetailOpen: state.actions.isDetailOpen,
        isRareBinderOpen: state.actions.isRareBinderOpen,
        isSearchOpen: state.actions.isSearchOpen,
        display: state.ui.deckView,
        groupBy: state.ui.deckGroup,
        sortBy: state.ui.deckSort
    }
    
    return result;
  }

export default connect(mapStateToProps)(DeckEditor)
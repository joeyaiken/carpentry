//export function 



export function generateDefaultDecks(): void {



}
/// <reference types="react-scripts" />
/// <reference types="mtgsdk-ts" />


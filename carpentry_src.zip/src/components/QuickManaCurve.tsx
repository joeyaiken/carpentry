import React from 'react';

export interface QuickManaCurveProps {

}

export default function QuickManaCurve(props: QuickManaCurveProps): JSX.Element {
    return(
        <div className="sd-quick-mana-curve outline-section">
            <label>Quick Mana Curve</label>
        </div>
    );
}
import React from 'react';

export interface QuickCardCountProps {

}

export default function QuickCardCount(props: QuickCardCountProps): JSX.Element {
    return(
        <div className="sd-quick-card-count outline-section">
            <label>Quick Card Count</label>
        </div>
    );
}
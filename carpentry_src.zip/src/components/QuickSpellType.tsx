import React from 'react';

export interface QuickSpellTypeProps {

}

export default function QuickSpellType(props: QuickSpellTypeProps): JSX.Element {
    return(
        <div className="sd-quick-spell-type outline-section">
            <label>Quick Spell Type</label>
        </div>
    );
}
import React from 'react';

export interface RareBinderProps {

}

export default function RareBinder(props: RareBinderProps): JSX.Element {
    return(
        <div className="sd-rare-binder card">
            <div className="card-header app-bar">
                <label>Rare Binder</label>
            </div>
            <div className="card-body">
            
            </div>
        </div>
    );
}